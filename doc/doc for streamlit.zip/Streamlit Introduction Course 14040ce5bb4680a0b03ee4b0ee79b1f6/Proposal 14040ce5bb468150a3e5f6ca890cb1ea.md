# Proposal

<aside>
💡

### Proposed solution

- A Streamlit interactive web application hosted on Streamlit Cloud.
- 1 page per section:
    - **EV Sales and Sales Share**
    - **Charging Points**
- Use visual Streamlit Components to display data according to the Analytical Requirements provided by the client.
</aside>